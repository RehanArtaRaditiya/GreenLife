//DOM 1: Ubah teks berdasarkan waktu 
const headerTitle = document.querySelector("h1");
const hour = new Date().getHours();
if (hour < 12) {
  headerTitle.textContent = "Selamat Pagi! 🌞 Hemat Energi, Selamatkan Lingkungan";
} else if (hour < 18) {
  headerTitle.textContent = "Selamat Siang! ☀️ Hemat Energi, Selamatkan Lingkungan";
} else {
  headerTitle.textContent = "Selamat Malam! 🌙 Hemat Energi, Selamatkan Lingkungan";
}

//DOM 2: Tambahkan jumlah pengunjung (simulasi dinamis) 
const mainContainer = document.querySelector(".main-container");
const visitorBox = document.createElement("div");
visitorBox.style.background = "#dcfce7";
visitorBox.style.padding = "12px";
visitorBox.style.borderRadius = "8px";
visitorBox.style.marginTop = "20px";
visitorBox.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
visitorBox.style.color = "#166534";
const randomVisitors = Math.floor(Math.random() * 500) + 100;
visitorBox.textContent = `🌿 Sudah ${randomVisitors} orang bergabung menjaga lingkungan hari ini!`;
mainContainer.appendChild(visitorBox);

//DOM 3: Tambahkan tombol interaktif + Snackbar 
const snackbarButton = document.createElement("button");
snackbarButton.textContent = "Saya Siap Menjaga Lingkungan!";
snackbarButton.classList.add("btn");
snackbarButton.style.marginTop = "20px";
snackbarButton.onclick = function () {
  showToast();
};
mainContainer.appendChild(snackbarButton);

//Fungsi Toast / Snackbar 
function showToast() {
  const snackbar = document.getElementById("snackbar");
  snackbar.className = "show";
  setTimeout(function () {
    snackbar.className = snackbar.className.replace("show", "");
  }, 3000);
}

//DOM 4: Dark Mode Toggle 
// Menambahkan event click untuk mengaktifkan atau menonaktifkan mode gelap
const darkToggle = document.getElementById("darkModeToggle");
darkToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");

  // Ganti ikon otomatis
  if (document.body.classList.contains("dark-mode")) {
    darkToggle.textContent = "☀️";
  } else {
    darkToggle.textContent = "🌙";
  }
});
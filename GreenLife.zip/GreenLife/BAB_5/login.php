<?php
session_start();
include 'koneksi.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // CEK USER
    $stmt = $koneksi->prepare("SELECT id_user, nama_user, username, password FROM tb_user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // SET SESSION
        $_SESSION['id_user']   = $user['id_user'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['nama_user'] = $user['nama_user'];
        $_SESSION['role']      = "user";

        // CATAT LOGIN DI tb_login
        $stmt2 = $koneksi->prepare("INSERT INTO tb_login (id_user, waktu_login, status) VALUES (?, NOW(), 'online')");
        $stmt2->bind_param("i", $user['id_user']);
        $stmt2->execute();
        $stmt2->close();

        header("Location: dashboard.php");
        exit;
    } else {
        $message = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>GreenLife - Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <main class="main-container center">
        <img src="assets/logo.png" alt="Logo GreenLife" class="logo">
        <h2>Login ke GreenLife</h2>
        <p class="tagline">Selamat datang kembali, mari jaga bumi bersama!</p>
        <hr class="ghost-60">

        <?php if (!empty($message)): ?>
            <p style="color: red;"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form action="login.php" method="post" class="form">
            <label>Username:</label>
            <input class="input-field" type="text" name="username" required>

            <label>Password:</label>
            <input class="input-field" type="password" name="password" required>

            <div style="text-align:center; margin-top:6px;">
                <button type="submit" class="btn">Login</button>
            </div>
        </form>

        <p>Belum punya akun? <a href="register.php" class="btn-secondary">Register</a></p>
        <hr class="ghost-40">

        <footer>
            <p>&copy; GreenLife 2025</p>
        </footer>
    </main>
</body>
</html>

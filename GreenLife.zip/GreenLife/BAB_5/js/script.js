window.addEventListener("DOMContentLoaded", () => {
  const headerTitle = document.querySelector("h1");
  if (headerTitle) {
    const hour = new Date().getHours();
    if (hour < 12) {
      headerTitle.textContent = "Selamat Pagi! 🌞 Hemat Energi, Selamatkan Lingkungan";
    } else if (hour < 18) {
      headerTitle.textContent = "Selamat Siang! ☀️ Hemat Energi, Selamatkan Lingkungan";
    } else {
      headerTitle.textContent = "Selamat Malam! 🌙 Hemat Energi, Selamatkan Lingkungan";
    }
  }

  // === 2. Tombol Interaktif & Snackbar ===
  const mainContainer = document.querySelector(".main-container");
  if (mainContainer) {
    const snackbarBtn = document.querySelector(".btn");
    if (snackbarBtn) {
      snackbarBtn.onclick = function () {
        const userConfirmed = confirm("Apakah Anda benar-benar siap menjaga lingkungan? Klik OK untuk lanjut!");
        if (userConfirmed) {
          showToast();
        } else {
          alert("Tidak masalah, mari pelajari lebih dulu! 🌍");
        }
      };
    }
  }

  // === Fungsi Toast ===
  function showToast(message = "Terima kasih telah peduli lingkungan 🌱") {
    const snackbar = document.getElementById("snackbar");
    if (snackbar) {
      snackbar.textContent = message;
      snackbar.className = "show";
      setTimeout(() => {
        snackbar.className = snackbar.className.replace("show", "");
      }, 3000);
    }
  }

  // === 3. Dark Mode Toggle ===
  const darkToggle = document.getElementById("darkModeToggle");
  if (darkToggle) {
    // Load mode sebelumnya
    if (localStorage.getItem("darkMode") === "enabled") {
      document.body.classList.add("dark-mode");
      darkToggle.textContent = "☀️";
    }

    darkToggle.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");
      if (document.body.classList.contains("dark-mode")) {
        localStorage.setItem("darkMode", "enabled");
        darkToggle.textContent = "☀️";
      } else {
        localStorage.setItem("darkMode", "disabled");
        darkToggle.textContent = "🌙";
      }
    });
  }

  // === 4. Pop-up Sambutan ===
if (
  window.location.pathname.endsWith("/") || 
  window.location.pathname.endsWith("/index.php")
) {
  setTimeout(() => {
    alert("Selamat datang di GreenLife! Mari bersama menjaga lingkungan 🌱");
  }, 2000);
}


  // === 5. Event Logo ===
  const logo = document.querySelector(".logo");
  if (logo) {
    logo.addEventListener("mouseover", () => {
      logo.title = "Klik untuk kembali ke Home";
      logo.style.transform = "scale(1.1)";
      logo.style.transition = "transform 0.3s ease";
    });
    logo.addEventListener("mouseout", () => {
      logo.style.transform = "scale(1)";
    });
    logo.addEventListener("click", () => {
      window.location.href = "index.php";
    });
  }

  // === 6. Event Keyboard Shortcut (Dark Mode) ===
  document.body.addEventListener("keydown", (event) => {
    if (event.key === "d" || event.key === "D") {
      if (darkToggle) darkToggle.click();
      showToast("Dark mode diaktifkan via keyboard (tombol D)! ⚡");
    }
  });

  // === 7. Event Scroll ===
  window.addEventListener("scroll", () => {
    if (window.scrollY > 100) {
      showToast("Jangan lupa hemat energi saat browsing! 💡");
    }
  });

  // === 8. Event Banner Double Click ===
  const banner = document.querySelector(".banner");
  if (banner) {
    banner.addEventListener("dblclick", () => {
      alert("Banner diklik dua kali! Mari belajar lebih banyak tentang lingkungan 🌿");
    });
  }
});

// === 9. Tombol Logout ===
const logoutBtn = document.querySelector(".btn-logout");
if (logoutBtn) {
  logoutBtn.addEventListener("click", (e) => {
    e.preventDefault();
    const confirmed = confirm("Apakah Anda yakin ingin logout dan kembali ke halaman utama?");
    if (confirmed) {
      // Hapus data login di localStorage jika ada
      localStorage.removeItem("isLoggedIn");
      // Arahkan ke halaman utama (tanpa logout.php)
      window.location.href = "index.php"; // cukup ini saja
    }
  });
}

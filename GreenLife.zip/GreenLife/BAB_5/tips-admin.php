<?php
session_start();
include 'koneksi.php';

// Cek login admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: login_admin.php');
    exit;
}

// Tambah Tips
if (isset($_POST['tambah'])) {
    $judul = trim($_POST['judul']);
    $deskripsi = trim($_POST['deskripsi']);
    $id_admin = $_SESSION['id_admin']; // ambil dari session login admin

    $stmt = $koneksi->prepare("INSERT INTO tb_tips (id_admin, judul, deskripsi) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $id_admin, $judul, $deskripsi);
    $stmt->execute();
    $stmt->close();

    header("Location: tips-admin.php"); // Refresh agar tabel update
    exit;
}

// Edit Tips
if (isset($_POST['edit'])) {
    $id_tips = $_POST['id_tips'];
    $judul = trim($_POST['judul']);
    $deskripsi = trim($_POST['deskripsi']);

    $stmt = $koneksi->prepare("UPDATE tb_tips SET judul = ?, deskripsi = ? WHERE id_tips = ?");
    $stmt->bind_param("ssi", $judul, $deskripsi, $id_tips);
    $stmt->execute();
    $stmt->close();
    header("Location: tips-admin.php");
    exit;
}

// Hapus Tips
if (isset($_GET['hapus'])) {
    $id_tips = $_GET['hapus'];
    $stmt = $koneksi->prepare("DELETE FROM tb_tips WHERE id_tips = ?");
    $stmt->bind_param("i", $id_tips);
    $stmt->execute();
    $stmt->close();
    header("Location: tips-admin.php");
    exit;
}

// Ambil semua tips dari database
$tipsData = [];
$result = $koneksi->query("SELECT tb_tips.*, tb_admin.nama_admin 
                           FROM tb_tips 
                           LEFT JOIN tb_admin ON tb_tips.id_admin = tb_admin.id_admin
                           ORDER BY id_tips ASC");
while ($row = $result->fetch_assoc()) {
    $tipsData[] = $row;
}

// Jika edit diklik, ambil data spesifik
$editData = null;
if (isset($_GET['edit'])) {
    $id_tips = $_GET['edit'];
    $stmt = $koneksi->prepare("SELECT * FROM tb_tips WHERE id_tips = ?");
    $stmt->bind_param("i", $id_tips);
    $stmt->execute();
    $editData = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Tips Lingkungan</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  <div class="admin-page">
    <div class="sidebar">
      <img src="assets/logo.png" alt="GreenLife Logo" class="logo-admin">
      <div class="menu">
        <a href="admin.php"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="tips-admin.php" class="active"><i class="fa-solid fa-leaf"></i> Tips Lingkungan</a>
        <a href="edukasi-admin.php"><i class="fa-solid fa-bolt"></i> Edukasi Energi</a>
      </div>
      <div class="logout">
        <a href="logout.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      </div>
    </div>

    <div class="main-content">
      <div class="header">
        <h1>💡 Data Tips Lingkungan</h1>
        <div class="admin-name">Admin: <?= htmlspecialchars($_SESSION['nama_admin']) ?></div>
      </div>

      <div class="content">
        <!-- Form Tambah / Edit -->
        <form method="post">
          <?php if ($editData): ?>
              <input type="hidden" name="id_tips" value="<?= $editData['id_tips'] ?>">
              <input type="text" name="judul" placeholder="Judul Tips" value="<?= htmlspecialchars($editData['judul']) ?>" required>
              <input type="text" name="deskripsi" placeholder="Deskripsi Tips" value="<?= htmlspecialchars($editData['deskripsi']) ?>" required>
              <button type="submit" name="edit" class="btn-add">Simpan Perubahan</button>
              <a href="tips-admin.php" class="btn-cancel">Batal</a>
          <?php else: ?>
              <input type="text" name="judul" placeholder="Judul Tips" required>
              <input type="text" name="deskripsi" placeholder="Deskripsi Tips" required>
              <button type="submit" name="tambah" class="btn-add">+ Tambah Tips</button>
          <?php endif; ?>
        </form>

        <!-- Tabel Tips -->
        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Judul</th>
              <th>Deskripsi</th>
              <th>Admin</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $no=1; foreach ($tipsData as $item): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($item['judul']) ?></td>
                <td><?= htmlspecialchars($item['deskripsi']) ?></td>
                <td><?= htmlspecialchars($item['nama_admin']) ?></td>
                <td>
                  <a href="?edit=<?= $item['id_tips'] ?>" class="btn-edit">Edit</a>
                  <a href="?hapus=<?= $item['id_tips'] ?>" onclick="return confirm('Yakin hapus data ini?')" class="btn-delete">Hapus</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

      </div>
    </div>
  </div>
</body>
</html>

<?php
session_start();
include 'koneksi.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // CEK ADMIN
    $stmt = $koneksi->prepare("SELECT id_admin, nama_admin, username, password FROM tb_admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if ($admin && password_verify($password, $admin['password'])) {
        // SET SESSION
        $_SESSION['id_admin']   = $admin['id_admin'];
        $_SESSION['username']   = $admin['username'];
        $_SESSION['nama_admin'] = $admin['nama_admin'];
        $_SESSION['role']       = "admin";

        // CATAT LOGIN DI tb_login
        $stmt2 = $koneksi->prepare("INSERT INTO tb_login (id_admin, waktu_login, status) VALUES (?, NOW(), 'online')");
        $stmt2->bind_param("i", $admin['id_admin']);
        $stmt2->execute();
        $stmt2->close();

        header("Location: admin.php");
        exit;
    } else {
        $message = "Username admin tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>GreenLife - Login Admin</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <main class="main-container center">
        <img src="assets/logo.png" alt="Logo GreenLife" class="logo">
        <h2>Login Admin</h2>
        <p class="tagline">Akses khusus administrator.</p>
        <hr class="ghost-60">

        <?php if ($message): ?>
            <p style="color: red; font-weight:bold;"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form action="login_admin.php" method="post" class="form">
            <label>Username:</label>
            <input class="input-field" type="text" name="username" required>

            <label>Password:</label>
            <input class="input-field" type="password" name="password" required>

            <div style="text-align:center; margin-top:6px;">
                <button type="submit" class="btn">Login</button>
            </div>
        </form>

        <hr class="ghost-40">
        <footer>
            <p>&copy; GreenLife 2025</p>
        </footer>
    </main>
</body>
</html>

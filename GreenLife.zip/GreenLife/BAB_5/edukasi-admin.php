<?php
session_start();
include 'koneksi.php';

// Cek login admin
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: login_admin.php');
    exit;
}

// Tambah Edukasi
if (isset($_POST['tambah'])) {
    $judul = trim($_POST['judul']);
    $deskripsi = trim($_POST['deskripsi']);
    $id_admin = $_SESSION['id_admin'];

    $stmt = $koneksi->prepare("INSERT INTO tb_edukasi (id_admin, judul, deskripsi) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $id_admin, $judul, $deskripsi);
    $stmt->execute();
    $stmt->close();

    header("Location: edukasi-admin.php");
    exit;
}

// Edit Edukasi
if (isset($_POST['edit'])) {
    $id_edukasi = $_POST['id_edukasi'];
    $judul = trim($_POST['judul']);
    $deskripsi = trim($_POST['deskripsi']);

    $stmt = $koneksi->prepare("UPDATE tb_edukasi SET judul = ?, deskripsi = ? WHERE id_edukasi = ?");
    $stmt->bind_param("ssi", $judul, $deskripsi, $id_edukasi);
    $stmt->execute();
    $stmt->close();

    header("Location: edukasi-admin.php");
    exit;
}

// Hapus Edukasi
if (isset($_GET['hapus'])) {
    $id_edukasi = $_GET['hapus'];
    $stmt = $koneksi->prepare("DELETE FROM tb_edukasi WHERE id_edukasi = ?");
    $stmt->bind_param("i", $id_edukasi);
    $stmt->execute();
    $stmt->close();

    header("Location: edukasi-admin.php");
    exit;
}

// Ambil semua edukasi dari database
$edukasiData = [];
$result = $koneksi->query("SELECT tb_edukasi.*, tb_admin.nama_admin 
                           FROM tb_edukasi 
                           LEFT JOIN tb_admin ON tb_edukasi.id_admin = tb_admin.id_admin
                           ORDER BY id_edukasi ASC");
while ($row = $result->fetch_assoc()) {
    $edukasiData[] = $row;
}

// Jika edit diklik
$editData = null;
if (isset($_GET['edit'])) {
    $id_edukasi = $_GET['edit'];
    $stmt = $koneksi->prepare("SELECT * FROM tb_edukasi WHERE id_edukasi = ?");
    $stmt->bind_param("i", $id_edukasi);
    $stmt->execute();
    $editData = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Edukasi Energi</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  <div class="admin-page">
    <div class="sidebar">
      <img src="assets/logo.png" alt="GreenLife Logo" class="logo-admin">
      <div class="menu">
        <a href="admin.php"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="tips-admin.php"><i class="fa-solid fa-leaf"></i> Tips Lingkungan</a>
        <a href="edukasi-admin.php" class="active"><i class="fa-solid fa-bolt"></i> Edukasi Energi</a>
      </div>
      <div class="logout">
        <a href="logout.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      </div>
    </div>

    <div class="main-content">
      <div class="header">
        <h1>⚡ Data Edukasi Energi</h1>
        <div class="admin-name">Admin: <?= htmlspecialchars($_SESSION['nama_admin']) ?></div>
      </div>

      <div class="content">
        <!-- Form Tambah / Edit -->
        <form method="post">
          <?php if ($editData): ?>
              <input type="hidden" name="id_edukasi" value="<?= $editData['id_edukasi'] ?>">
              <input type="text" name="judul" placeholder="Judul Edukasi" value="<?= htmlspecialchars($editData['judul']) ?>" required>
              <input type="text" name="deskripsi" placeholder="Deskripsi Edukasi" value="<?= htmlspecialchars($editData['deskripsi']) ?>" required>
              <button type="submit" name="edit" class="btn-add">Simpan Perubahan</button>
              <a href="edukasi-admin.php" class="btn-cancel">Batal</a>
          <?php else: ?>
              <input type="text" name="judul" placeholder="Judul Edukasi" required>
              <input type="text" name="deskripsi" placeholder="Deskripsi Edukasi" required>
              <button type="submit" name="tambah" class="btn-add">+ Tambah Edukasi</button>
          <?php endif; ?>
        </form>

        <!-- Tabel Edukasi -->
        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Judul</th>
              <th>Deskripsi</th>
              <th>Admin</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $no=1; foreach ($edukasiData as $item): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($item['judul']) ?></td>
                <td><?= htmlspecialchars($item['deskripsi']) ?></td>
                <td><?= htmlspecialchars($item['nama_admin']) ?></td>
                <td>
                  <a href="?edit=<?= $item['id_edukasi'] ?>" class="btn-edit">Edit</a>
                  <a href="?hapus=<?= $item['id_edukasi'] ?>" onclick="return confirm('Yakin hapus data ini?')" class="btn-delete">Hapus</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

      </div>
    </div>
  </div>
</body>
</html>

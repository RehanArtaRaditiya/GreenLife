<?php
session_start();
include 'koneksi.php';

// Pastikan user/admin sudah login
if (isset($_SESSION['id_user']) || isset($_SESSION['id_admin'])) {

    $id_login = $_SESSION['id_login'] ?? null; // Ambil id_login dari session

    if ($id_login) {
        // Update status menjadi offline dan catat waktu_logout
        $stmt = $koneksi->prepare("UPDATE tb_login SET status = ?, waktu_logout = NOW() WHERE id_login = ?");
        $offline = "offline";
        $stmt->bind_param("si", $offline, $id_login);
        $stmt->execute();
        $stmt->close();
    }

    // Hapus semua session
    session_unset();
    session_destroy();
}

// Redirect ke halaman login
header("Location: login.php");
exit;

<?php
session_start();
include 'koneksi.php';
// Hitung jumlah data
$jmlTips = $koneksi->query("SELECT COUNT(*) as total FROM tb_tips")->fetch_assoc()['total'];
$jmlEdukasi = $koneksi->query("SELECT COUNT(*) as total FROM tb_edukasi")->fetch_assoc()['total'];
$jmlAdmin = $koneksi->query("SELECT COUNT(*) as total FROM tb_admin")->fetch_assoc()['total'];

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: login_admin.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - GreenLife</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  <div class="admin-page">
    <div class="sidebar">
      <img src="assets/logo.png" alt="GreenLife Logo" class="logo-admin">
      <h2>Admin Panel</h2>
      <div class="menu">
        <a href="admin.php" class="active"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="tips-admin.php"><i class="fa-solid fa-leaf"></i> Tips Lingkungan</a>
        <a href="edukasi-admin.php"><i class="fa-solid fa-bolt"></i> Edukasi Energi</a>
      </div>
      <div class="logout">
        <a href="logout.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        
      </div>
    </div>

    <div class="main-content">
      <div class="header">
        <h1>Dashboard Admin</h1>
        <div class="admin-name">Admin GreenLife</div>
      </div>
      <p>Selamat datang di panel admin. Kelola data tips dan edukasi dari sini.</p>
      <div class="dashboard-widgets">
    <div class="widget">
    <h3>Total Tips Lingkungan</h3>
    <p><?= $jmlTips ?></p>
    </div>
    <div class="widget">
    <h3>Total Edukasi Energi</h3>
    <p><?= $jmlEdukasi ?></p>
    </div>
    <div class="widget">
    <h3>Total Admin</h3>
    <p><?= $jmlAdmin ?></p>
    </div>
  </div>

    </div>
  </div>

  <script src="js/script.js"></script>
</body>
</html>
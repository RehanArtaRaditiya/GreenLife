<?php
include 'koneksi.php';
require_once("dompdf/autoload.inc.php");

use Dompdf\Dompdf;

$dompdf = new Dompdf();

$query = mysqli_query($koneksi, "
    SELECT tb_tips.*, tb_admin.nama_admin
    FROM tb_tips
    LEFT JOIN tb_admin 
    ON tb_tips.id_admin = tb_admin.id_admin
");

$html = '<center><h3>Laporan Data Tips Lingkungan</h3></center><hr/><br>';
$html .= '<table border="1" width="100%" cellpadding="5" cellspacing="0">
            <tr style="background:#f2f2f2; font-weight:bold;">
                <th>No</th>
                <th>Judul</th>
                <th>Deskripsi</th>
                <th>Admin</th>
            </tr>';

$no = 1;
while ($row = mysqli_fetch_assoc($query)) {
    $html .= "
        <tr>
            <td>{$no}</td>
            <td>{$row['judul']}</td>
            <td>{$row['deskripsi']}</td>
            <td>{$row['nama_admin']}</td>
        </tr>";
    $no++;
}

$html .= "</table>";

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('laporan-tips.pdf');
?>

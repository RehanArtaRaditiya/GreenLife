window.addEventListener("DOMContentLoaded", () => {
  // DOM 1: Ubah teks berdasarkan waktu 
  const headerTitle = document.querySelector("h1");
  if (headerTitle) {
    const hour = new Date().getHours();
    if (hour < 12) {
      headerTitle.textContent = "Selamat Pagi! 🌞 Hemat Energi, Selamatkan Lingkungan";
    } else if (hour < 18) {
      headerTitle.textContent = "Selamat Siang! ☀️ Hemat Energi, Selamatkan Lingkungan";
    } else {
      headerTitle.textContent = "Selamat Malam! 🌙 Hemat Energi, Selamatkan Lingkungan";
    }
  }

  // DOM 2: Tambahkan jumlah pengunjung
  // Fitur ini menampilkan jumlah pengunjung yang bertambah dinamis menggunakan localStorage
  const mainContainer = document.querySelector(".main-container");
  if (mainContainer && window.location.pathname.includes("index.html")) {  
    const visitorBox = document.createElement("div");
    visitorBox.style.background = "#dcfce7";
    visitorBox.style.padding = "12px";
    visitorBox.style.borderRadius = "8px";
    visitorBox.style.marginTop = "20px";
    visitorBox.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
    visitorBox.style.color = "#166534";
    mainContainer.appendChild(visitorBox);

    // Fungsi untuk mengambil dan menambah jumlah pengunjung dari localStorage
    // Menggunakan Promise untuk menangani fetch secara asynchronous
    function fetchVisitorData() {
      return new Promise((resolve) => {
        // Ambil jumlah pengunjung dari localStorage 
        let currentVisitors = parseInt(localStorage.getItem("visitorCount")) || 100;
    
        const increment = Math.floor(Math.random() * 10) + 1;
        currentVisitors += increment;
        
        // Simpan kembali ke localStorage
        localStorage.setItem("visitorCount", currentVisitors);
        
        // Fetch data dari API sebagai fallback atau untuk inisialisasi (asynchronous)
        fetch('https://jsonplaceholder.typicode.com/posts/1')
          .then(response => response.json())
          .then(data => {
            const apiBase = data.id * 100; 
            resolve(currentVisitors + apiBase); 
          })
          .catch(error => {
            console.error('Error fetching data:', error);
            // Jika fetch gagal, gunakan hanya dari localStorage
            resolve(currentVisitors);
          });
      });
    }
    fetchVisitorData().then(visitors => {
      visitorBox.textContent = `🌿 Sudah ${visitors} orang bergabung menjaga lingkungan hari ini!`;
    });
  }

  // DOM 3: Tambahkan tombol interaktif + Snackbar
  // Tombol ini memicu toast dan pop-up confirm
  if (mainContainer && window.location.pathname.includes("index.html")) { 
    const snackbarButton = document.createElement("button");
    snackbarButton.textContent = "Saya Siap Menjaga Lingkungan!";
    snackbarButton.classList.add("btn");
    snackbarButton.style.marginTop = "20px";
    snackbarButton.onclick = function () {
      showToast();
    };
    mainContainer.appendChild(snackbarButton);
  }

  // Fungsi Toast / Snackbar
  // Menampilkan pesan sementara di layar bawah
  function showToast(message = "Terima kasih telah peduli lingkungan 🌱") {
    const snackbar = document.getElementById("snackbar");
    if (snackbar) {
      snackbar.textContent = message;
      snackbar.className = "show";
      setTimeout(() => {
        snackbar.className = snackbar.className.replace("show", "");
      }, 3000);
    }
  }

  // DOM 4: Dark Mode Toggle 
  // Menggunakan localStorage untuk menyimpan status dark mode
  const darkToggle = document.getElementById("darkModeToggle");
  if (darkToggle) {
    // Load dark mode dari localStorage
    if (localStorage.getItem("darkMode") === "enabled") {
      document.body.classList.add("dark-mode");
      darkToggle.textContent = "☀️";
    }

    // Event listener untuk toggle
    darkToggle.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");
      if (document.body.classList.contains("dark-mode")) {
        localStorage.setItem("darkMode", "enabled");
        darkToggle.textContent = "☀️";
      } else {
        localStorage.setItem("darkMode", "disabled");
        darkToggle.textContent = "🌙";
      }
    });
  }

  // FITUR BARU: 2 PopUp Boxes 
  // Pop-up 1: Alert otomatis setelah 2 detik
  // Pop-up 2: Confirm saat klik tombol
  if (window.location.pathname.includes("index.html")) {
    setTimeout(() => {
      alert("Selamat datang di GreenLife! Mari bersama menjaga lingkungan 🌱");
    }, 2000);

    const snackbarBtn = document.querySelector(".btn"); 
    if (snackbarBtn) {
      snackbarBtn.onclick = function () {
        const userConfirmed = confirm("Apakah Anda benar-benar siap menjaga lingkungan? Klik OK untuk lanjut!");
        if (userConfirmed) {
          showToast();
        } else {
          alert("Tidak masalah, mari pelajari lebih dulu! 🌍");
        }
      };
    }
  }

  // FITUR BARU: 3 Events 
  // Event pada logo: Mouseover (besar), Mouseout (kecil), dan Click (navigasi ke home)
  // Efek ini berlaku di semua halaman yang punya logo (.logo)
  const logo = document.querySelector(".logo");
  if (logo) {
    // Mouseover: Logo membesar dan tampilkan title
    logo.addEventListener("mouseover", () => {
      logo.title = "Klik untuk kembali ke Home";
      logo.style.transform = "scale(1.1)"; // Besar saat mouse masuk
      logo.style.transition = "transform 0.3s ease";
    });
    // Mouseout: Logo kembali normal
    logo.addEventListener("mouseout", () => {
      logo.style.transform = "scale(1)"; // Kecil saat mouse keluar
    });
    // Click: Navigasi ke index.html (home)
    logo.addEventListener("click", () => {
      window.location.href = "index.html"; // Redirect ke home
    });
  }

  // Event 2: Keydown pada body (keyboard shortcut untuk dark mode)
  document.body.addEventListener("keydown", (event) => {
    if (event.key === "d" || event.key === "D") {
      if (darkToggle) darkToggle.click();
      alert("Dark mode toggled via keyboard shortcut!");
    }
  });

  // Event 3: Scroll pada window (toast saat scroll)
  window.addEventListener("scroll", () => {
    if (window.scrollY > 100) {
      showToast("Jangan lupa hemat energi saat browsing! 💡");
    }
  });

  // Event Bonus: Dblclick pada banner (double-click alert)
  const banner = document.querySelector(".banner");
  if (banner) {
    banner.addEventListener("dblclick", () => {
      alert("Banner diklik dua kali! Mari belajar lebih banyak tentang lingkungan 🌿");
    });
  }
});
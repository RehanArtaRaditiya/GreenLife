<?php
session_start();
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = trim($_POST['nama']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    if ($password !== $confirm_password) {
        $message = 'Password tidak cocok!';
    } elseif (empty($nama) || empty($username) || empty($email) || empty($password)) {
        $message = 'Semua field harus diisi!';
    } else {
        // Simpan ke file sederhana 
        $userData = "$username|$password|$nama|$email\n";
        file_put_contents('users.txt', $userData, FILE_APPEND);
        $message = 'Registrasi berhasil! Silakan login.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>GreenLife - Register</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <main class="main-container center">
    <img src="assets/logo.png" alt="Logo GreenLife" class="logo">
    <h2>Daftar ke GreenLife</h2>
    <p class="tagline">Bergabunglah bersama kami untuk menjaga bumi lebih hijau!</p>
    <hr class="ghost-60">

    <?php if ($message): ?>
        <p style="color: <?php echo strpos($message, 'berhasil') !== false ? 'green' : 'red'; ?>;"><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>

    <form action="register.php" method="post" class="form">
      <label>Nama Lengkap:</label>
      <input class="input-field" type="text" name="nama" required>

      <label>Username:</label>
      <input class="input-field" type="text" name="username" required>

      <label>Email:</label>
      <input class="input-field" type="email" name="email" required>

      <label>Password:</label>
      <input class="input-field" type="password" name="password" required>

      <label>Konfirmasi Password:</label>
      <input class="input-field" type="password" name="confirm_password" required>

      <div style="text-align:center; margin-top:6px;">
        <button type="submit" class="btn">Register</button>
      </div>
    </form>

    <p>Sudah punya akun? <a href="login.php" class="btn-secondary">Login</a></p>
    <hr class="ghost-40">
    <footer>
      <p>&copy; GreenLife 2025</p>
    </footer>
  </main>

<script src="js/script.js"></script>
</body>
</html>
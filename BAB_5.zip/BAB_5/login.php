<?php
session_start();
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Simulasi pengguna
    $users = [
        'admin' => 'admin123',
        'user' => 'user123'
    ];

    if (isset($users[$username]) && $users[$username] == $password) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = ($username == 'admin') ? 'admin' : 'user';

        // Admin langsung ke dashboard admin
        header('Location: admin.php');
        exit;
    } else {
        $message = 'Username atau password salah!';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>GreenLife - Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <main class="main-container center">
        <img src="assets/logo.png" alt="Logo GreenLife" class="logo">
        <h2>Login ke GreenLife</h2>
        <p class="tagline">Selamat datang kembali, mari jaga bumi bersama!</p>
        <hr class="ghost-60">
        <?php if ($message): ?>
            <p style="color: red;"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        <form action="login.php" method="post" class="form">
            <label for="username">Username:</label>
            <input id="username" class="input-field" type="text" name="username" placeholder="Masukkan username" required>
            <label for="password">Password:</label>
            <input id="password" class="input-field" type="password" name="password" placeholder="********" required>
            <div style="text-align:center; margin-top:6px;">
                <button type="submit" class="btn">Login</button>
            </div>
        </form>
        <p>Belum punya akun? <a href="register.php" class="btn-secondary">Register</a></p>
        <hr class="ghost-40">
        <footer>
            <p>&copy; GreenLife 2025</p>
        </footer>
    </main>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

$tipsData = [
    ['no' => 1, 'judul' => 'Kurangi Penggunaan Plastik', 'deskripsi' => 'Gunakan tas belanja kain dan botol isi ulang untuk kehidupan yang lebih hijau.'],
    ['no' => 2, 'judul' => 'Tanam Pohon di Sekitar Rumah', 'deskripsi' => 'Menanam pohon membantu menyerap karbon dan menjaga udara tetap segar.']
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Tips Lingkungan</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>
  <div class="admin-page">
    <div class="sidebar">
      <img src="assets/logo.png" alt="GreenLife Logo" class="logo-admin">
      <div class="menu">
        <a href="admin.php"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="tips-admin.php" class="active"><i class="fa-solid fa-leaf"></i> Tips Lingkungan</a>
        <a href="edukasi-admin.php"><i class="fa-solid fa-bolt"></i> Edukasi Energi</a>
      </div>
      <div class="logout">
     <a href="#" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      </div>
    </div>

    <div class="main-content">
      <div class="header">
        <h1>💡 Data Tips Lingkungan</h1>
        <div class="admin-name">Admin GreenLife</div>
      </div>

      <div class="content">
        <p style="margin-bottom: 20px;">Tips lingkungan untuk gaya hidup hijau berkelanjutan.</p>

        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Judul Tips</th>
              <th>Deskripsi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($tipsData as $item): ?>
              <tr>
                <td><?= $item['no'] ?></td>
                <td><?= htmlspecialchars($item['judul']) ?></td>
                <td><?= htmlspecialchars($item['deskripsi']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<script>
  document.addEventListener("DOMContentLoaded", () => {
    const logoutBtn = document.querySelector('.btn-logout');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const confirmed = confirm("Konfirmasi Logout: Apakah Anda ingin kembali ke halaman utama? 🌿");
        if (confirmed) {
          // ✅ Arahkan langsung ke halaman utama
          window.location.href = "index.php";
        }
      });
    }
  });
</script>


</body>
</html>

<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - GreenLife</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>
  <div class="admin-page">
    <div class="sidebar">
      <img src="assets/logo.png" alt="GreenLife Logo" class="logo-admin">
      <h2>Admin Panel</h2>
      <div class="menu">
        <a href="admin.php" class="active"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="tips-admin.php"><i class="fa-solid fa-leaf"></i> Tips Lingkungan</a>
        <a href="edukasi-admin.php"><i class="fa-solid fa-bolt"></i> Edukasi Energi</a>
      </div>
      <div class="logout">
        <a href="#" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      <i class="fa-solid fa-right-from-bracket"></i> Logout
      </a>
      </div>
    </div>

    <div class="main-content">
      <div class="header">
        <h1>Dashboard Admin</h1>
        <div class="admin-name">Admin GreenLife</div>
      </div>
      <p>Selamat datang di panel admin. Kelola data tips dan edukasi dari sini.</p>
    </div>
  </div>

<script>
  document.addEventListener("DOMContentLoaded", () => {
    const logoutBtn = document.querySelector('.btn-logout');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const confirmed = confirm("Konfirmasi Logout: Apakah Anda ingin kembali ke halaman utama? 🌿");
        if (confirmed) {
          // ✅ Arahkan langsung ke halaman utama
          window.location.href = "index.php";
        }
      });
    }
  });
</script>


</body>
</html>

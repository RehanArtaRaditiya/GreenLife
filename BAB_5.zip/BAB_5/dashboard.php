<?php
session_start(); 
if (!isset($_SESSION['username'])) {
    session_destroy();
    header('Location: index.php'); // kembali ke halaman utama
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Pengguna - GreenLife</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <header>
    <div class="header-inner">
      <img src="assets/logo.png" alt="GreenLife Logo" class="logo">
      <nav>
        <a href="#" class="active">Dashboard</a>
        <a href="index.php">Home</a>
        <?php if ($_SESSION['role'] == 'admin'): ?>
            <a href="admin.php">Admin</a>
        <?php endif; ?>
      </nav>
      <!-- Tombol Dark Mode -->
      <button id="darkModeToggle" title="Ganti Mode" aria-label="Dark Mode">🌙</button>
    </div>
  </header>

  <main class="main-container">
    <section class="welcome-box">
      <h2>🌿 Selamat Datang, <?php echo htmlspecialchars($_SESSION['username']); ?> 🌿</h2>
      <p>Terima kasih sudah bergabung bersama kami. Yuk, mulai belajar menjaga bumi lebih hijau!</p>
    </section>

    <div class="cards-container">
      <div class="card">
        <h3>💡 Tips Ramah Lingkungan</h3>
        <p>Pelajari cara menggunakan energi terbarukan dan hidup ramah lingkungan setiap hari.</p>
        <a href="#tipsModal" class="btn">Lihat Tips Lainnya</a>
      </div>

      <div class="card">
        <h3>⚡ Edukasi Energi</h3>
        <p>Matikan lampu dan perangkat elektronik saat tidak digunakan untuk menghemat energi.</p>
        <a href="#edukasiModal" class="btn">Pelajari Sekarang</a>
      </div>
    </div>

    <button class="btn-logout">Logout</button>
  </main>

  <footer>
    <p>© 2025 <i>GreenLife</i> - Bersama Menjaga Lingkungan 🌱</p>
  </footer>

  <div id="tipsModal" class="modal">
    <div class="modal-content">
      <a href="#" class="close">&times;</a>
      <h2>💡 Tips Ramah Lingkungan</h2>
      <p>Langkah kecil kita bisa berdampak besar bagi bumi! Berikut beberapa tips sederhana:</p>
      <ul>
        <li><b>Kurangi Plastik Sekali Pakai:</b> Gunakan tas belanja kain dan botol isi ulang.</li>
        <li><b>Gunakan Transportasi Umum:</b> Kurangi polusi udara dan hemat energi.</li>
        <li><b>Tanam Pohon di Rumah:</b> Membantu serap karbon dan memperindah lingkungan.</li>
        <li><b>Daur Ulang Barang Bekas:</b> Ubah barang lama jadi produk bermanfaat kembali.</li>
        <li><b>Hemat Energi di Rumah:</b> Gunakan lampu LED dan matikan alat elektronik.</li>
      </ul>
    </div>
  </div>

  <div id="edukasiModal" class="modal">
    <div class="modal-content">
      <a href="#" class="close">&times;</a>
      <h2>⚡ Edukasi Energi</h2>
      <p>Energi adalah sumber kehidupan manusia. Mari pelajari cara menggunakan energi dengan bijak:</p>
      <ul>
        <li><b>Kenali Energi Terbarukan:</b> Sumber seperti matahari, air, dan angin tidak akan habis.</li>
        <li><b>Hemat Penggunaan Listrik:</b> Matikan peralatan saat tidak digunakan.</li>
        <li><b>Gunakan Panel Surya:</b> Solusi ramah lingkungan untuk rumah hemat energi.</li>
        <li><b>Efisiensi Air:</b> Gunakan air secukupnya agar tidak boros energi listrik.</li>
        <li><b>Edukasi Sejak Dini:</b> Ajak anak-anak peduli terhadap energi dan lingkungan.</li>
      </ul>
    </div>
  </div>

     <script>
       const logoutBtn = document.querySelector('.btn-logout');
       if (logoutBtn) {
         logoutBtn.addEventListener('click', (e) => {
           e.preventDefault(); 
           const confirmed = confirm("Konfirmasi Logout: Apakah Anda ingin kembali ke halaman utama? Mari jaga lingkungan bersama lagi nanti! 🌿");
           if (confirmed) {
             window.location.href = 'index.php'; 
           }
         });
       }
     </script>
     
  <script src="js/script.js"></script>
</body>
</html>
<?php
session_start();

// === Greeting Dinamis Berdasarkan Waktu ===
$hour = date('H');
if ($hour < 12) {
    $greeting = "Selamat Pagi! 🌞 Hemat Energi, Selamatkan Lingkungan";
} elseif ($hour < 18) {
    $greeting = "Selamat Siang! ☀️ Hemat Energi, Selamatkan Lingkungan";
} else {
    $greeting = "Selamat Malam! 🌙 Hemat Energi, Selamatkan Lingkungan";
}

// === Jumlah Pengunjung ===
$visitorFile = 'visitors.txt';
$currentVisitors = file_exists($visitorFile) ? (int)file_get_contents($visitorFile) : 100;
$currentVisitors += rand(1, 10);
file_put_contents($visitorFile, $currentVisitors);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Home</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <header>
    <div class="header-inner">
      <div>
        <img src="assets/logo.png" alt="Logo GreenLife" class="logo">
      </div>
      <nav>
        <a href="index.php" class="active">Home</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
      </nav>
      
      <button id="darkModeToggle" title="Ganti Mode" aria-label="Dark Mode">🌙</button>
    </div>
  </header>

  <main class="main-container center">
    <h1><?php echo htmlspecialchars($greeting); ?></h1>
    <p class="tagline">Bersama GreenLife kita belajar menjaga bumi lebih hijau</p>
    <hr class="ghost-60">

    <img src="assets/banner.png" alt="Banner GreenLife" class="banner">

    <section class="about">
      <h2>Tentang GreenLife</h2>
      <p>
        GreenLife adalah portal edukasi yang membahas tentang pentingnya hemat energi dan menjaga lingkungan.
        Melalui web ini, pengguna bisa mendapatkan informasi tentang energi terbarukan, tips gaya hidup ramah lingkungan,
        serta ajakan untuk berpartisipasi dalam menjaga bumi agar tetap hijau dan berkelanjutan.
      </p>
    </section>

    <!-- ===== Box Pengunjung ===== -->
    <div style="
      background: #dcfce7; 
      padding: 12px; 
      border-radius: 8px; 
      margin-top: 20px; 
      box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
      color: #166534;
    ">
      🌿 Sudah <?php echo $currentVisitors; ?> orang bergabung menjaga lingkungan hari ini!
    </div>

    <!-- ===== Tombol Interaktif ===== -->
    <button class="btn" style="margin-top: 20px;">
      Saya Siap Menjaga Lingkungan!
    </button>

    <hr class="ghost-40">
  </main>

  <footer>
    <p><strong>Selamat datang di GreenLife!</strong></p>
    <p>&copy; 2025 GreenLife — Bersama Menjaga Lingkungan</p>
  </footer>

  <div id="snackbar">Terima kasih telah peduli lingkungan 🌱</div>

  <script src="js/script.js"></script>
</body>
</html>

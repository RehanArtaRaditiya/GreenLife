<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - GreenLife</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  <div class="admin-page">

    <!-- SIDEBAR -->
    <div class="sidebar">
      <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="GreenLife Logo" class="logo-admin">
      <h2>Admin Panel</h2>

      <div class="menu">
        <a href="/admin" class="active"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="/admin/tips"><i class="fa-solid fa-leaf"></i> Tips Lingkungan</a>
        <a href="/admin/edukasi"><i class="fa-solid fa-bolt"></i> Edukasi Energi</a>
      </div>

      <div class="logout">
        <a href="/logout-admin" class="btn-logout">
          <i class="fa-solid fa-right-from-bracket"></i> Logout
        </a>
      </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
      <div class="header">
        <h1>Dashboard Admin</h1>
        <div class="admin-name">Admin GreenLife</div>
      </div>

      <p>Selamat datang di panel admin. Kelola data tips dan edukasi dari sini.</p>

      <div class="dashboard-widgets">
        <div class="widget">
          <h3>Total Tips Lingkungan</h3>
          <p><?php echo e($jmlTips); ?></p>
        </div>

        <div class="widget">
          <h3>Total Edukasi Energi</h3>
          <p><?php echo e($jmlEdukasi); ?></p>
        </div>

        <div class="widget">
          <h3>Total Admin</h3>
          <p><?php echo e($jmlAdmin); ?></p>
        </div>
      </div>
    </div>

  </div>
</body>
</html><?php /**PATH C:\laragon\www\laravel-greenlife\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
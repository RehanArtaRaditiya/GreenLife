<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Edukasi Energi - GreenLife</title>

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 12px;
        }

        h2, h3 {
            text-align: center;
            margin: 0;
        }

        hr {
            margin: 10px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th {
            background: #eeeeee;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        .tanggal {
            text-align: right;
            margin-top: 20px;
        }

        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 12px;
        }
    </style>
</head>
<body>

<h2>LAPORAN DATA EDUKASI ENERGI</h2>
<h3>Website GreenLife - Edukasi Lingkungan & Energi</h3>
<hr>

<table>
    <thead>
        <tr>
            <th width="5%">No</th>
            <th width="25%">Judul</th>
            <th width="50%">Deskripsi</th>
            <th width="20%">Admin</th>
        </tr>
    </thead>
    <tbody>

        <?php $no = 1; ?>
        <?php $__currentLoopData = $edukasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($e->judul); ?></td>
            <td><?php echo e($e->deskripsi); ?></td>
            <td><?php echo e($e->nama_admin); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>

<div class="tanggal">
    Dicetak pada : <?php echo e(date('d M Y - H:i')); ?>

</div>

<div class="footer">
    <p>© 2025 - GreenLife | Edukasi Lingkungan & Energi</p>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\laravel-greenlife\resources\views/admin/report-edukasi.blade.php ENDPATH**/ ?>
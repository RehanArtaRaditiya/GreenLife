<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Edukasi Energi</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="admin-page">

  <!-- SIDEBAR -->
  <div class="sidebar">
    <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="GreenLife Logo" class="logo-admin">

    <div class="menu">
      <a href="/admin"><i class="fa-solid fa-house"></i> Dashboard</a>
      <a href="/admin/tips"><i class="fa-solid fa-leaf"></i> Tips Lingkungan</a>
      <a href="/admin/edukasi" class="active"><i class="fa-solid fa-bolt"></i> Edukasi Energi</a>
    </div>

    <div class="logout">
      <a href="/logout-admin" class="btn-logout">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </a>
    </div>
  </div>

  <!-- MAIN CONTENT -->
  <div class="main-content">

    <!-- HEADER -->
    <div class="header">
      <h1>⚡ Data Edukasi Energi</h1>
      <div class="admin-name">Admin: <?php echo e(session('nama_admin')); ?></div>
    </div>

    <div class="content">

      <!-- FORM TAMBAH / EDIT -->
      <form method="post" action="<?php echo e(isset($editData) ? '/admin/edukasi/update' : '/admin/edukasi/store'); ?>">
        <?php echo csrf_field(); ?>

        <?php if($editData): ?>
            <input type="hidden" name="id_edukasi" value="<?php echo e($editData->id_edukasi); ?>">

            <input type="text" 
                   name="judul" 
                   placeholder="Judul Edukasi"
                   value="<?php echo e($editData->judul); ?>" 
                   required>

            <input type="text" 
                   name="deskripsi" 
                   placeholder="Deskripsi Edukasi"
                   value="<?php echo e($editData->deskripsi); ?>" 
                   required>

            <button type="submit" class="btn-add">Simpan Perubahan</button>
            <a href="/admin/edukasi" class="btn-cancel">Batal</a>

        <?php else: ?>
            <input type="text" name="judul" placeholder="Judul Edukasi" required>
            <input type="text" name="deskripsi" placeholder="Deskripsi Edukasi" required>
            <button type="submit" class="btn-add">+ Tambah Edukasi</button>
        <?php endif; ?>
      </form>

      <!-- TOMBOL CETAK -->
      <div style="margin: 15px 0;">
        <a href="/admin/edukasi/cetak" class="btn-print-modern" target="_blank">
            <i class="fa-solid fa-print"></i> Cetak Data
        </a>
      </div>

      <!-- TABEL EDUKASI -->
      <table class="table">
        <thead>
          <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Deskripsi</th>
            <th>Admin</th>
            <th>Aksi</th>
          </tr>
        </thead>

        <tbody>
          <?php $no = 1; ?>

          <?php $__currentLoopData = $edukasiData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($item->judul); ?></td>
            <td><?php echo e($item->deskripsi); ?></td>
            <td><?php echo e($item->nama_admin); ?></td>

            <td>
              <a href="/admin/edukasi?edit=<?php echo e($item->id_edukasi); ?>" class="btn-edit">Edit</a>

              <a href="/admin/edukasi/hapus/<?php echo e($item->id_edukasi); ?>" 
                 onclick="return confirm('Yakin hapus data ini?')"
                 class="btn-delete">Hapus</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

      </table>

    </div>
  </div>

</div>

</body>
</html><?php /**PATH C:\laragon\www\laravel-greenlife\resources\views/admin/edukasi-admin.blade.php ENDPATH**/ ?>
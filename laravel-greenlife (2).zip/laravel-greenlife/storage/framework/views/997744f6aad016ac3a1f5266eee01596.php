<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Tips Lingkungan</title>

  
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="admin-page">
  <div class="sidebar">
    <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="GreenLife Logo" class="logo-admin">

    <div class="menu">
      <a href="/admin"><i class="fa-solid fa-house"></i> Dashboard</a>

      <a href="/admin/tips" class="active">
        <i class="fa-solid fa-leaf"></i> Tips Lingkungan
      </a>

      <a href="/admin/edukasi">
        <i class="fa-solid fa-bolt"></i> Edukasi Energi
      </a>
    </div>

    <div class="logout">
      <a href="/logout-admin" class="btn-logout">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </a>
    </div>
  </div>

  <div class="main-content">

    <div class="header">
      <h1>💡 Data Tips Lingkungan</h1>
      <div class="admin-name">Admin: <?php echo e(session('nama_admin')); ?></div>
    </div>

    <div class="content">

      <form method="post" action="<?php echo e(isset($editData) ? '/admin/tips/update' : '/admin/tips/store'); ?>">
        <?php echo csrf_field(); ?>

        <?php if($editData): ?>
          <input type="hidden" name="id_tips" value="<?php echo e($editData->id_tips); ?>">
          <input type="text" name="judul" value="<?php echo e($editData->judul); ?>" required>
          <input type="text" name="deskripsi" value="<?php echo e($editData->deskripsi); ?>" required>

          <button type="submit" class="btn-add">Simpan Perubahan</button>
          <a href="/admin/tips" class="btn-cancel">Batal</a>

        <?php else: ?>
          <input type="text" name="judul" placeholder="Judul Tips" required>
          <input type="text" name="deskripsi" placeholder="Deskripsi Tips" required>

          <button type="submit" class="btn-add">+ Tambah Tips</button>
        <?php endif; ?>
      </form>

      <div style="margin: 15px 0;">
        <a href="/admin/tips/cetak" class="btn-print-modern">
          <i class="fa-solid fa-print"></i> Cetak PDF
        </a>
      </div>

      <table class="table">
        <thead>
          <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Deskripsi</th>
            <th>Admin</th>
            <th>Aksi</th>
          </tr>
        </thead>

        <tbody>
          <?php $no = 1; ?>
          <?php $__currentLoopData = $tipsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($item->judul); ?></td>
            <td><?php echo e($item->deskripsi); ?></td>
            <td><?php echo e($item->nama_admin); ?></td>
            <td>
              <a href="/admin/tips?edit=<?php echo e($item->id_tips); ?>" class="btn-edit">Edit</a>

              <a href="/admin/tips/hapus/<?php echo e($item->id_tips); ?>"
                 onclick="return confirm('Yakin hapus data ini?')"
                 class="btn-delete">
                 Hapus
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    </div>
  </div>

</div>

</body>
</html><?php /**PATH C:\laragon\www\laravel-greenlife\resources\views/admin/tips-admin.blade.php ENDPATH**/ ?>
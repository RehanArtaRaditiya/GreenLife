<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>GreenLife - Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<main class="main-container center">
    <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo GreenLife" class="logo">
    <h2>Login ke GreenLife</h2>
    <p class="tagline">Selamat datang kembali, mari jaga bumi bersama!</p>
    <hr class="ghost-60">

    <?php if(session('error')): ?>
        <p style="color:red;"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <form method="POST" action="/login" class="form">
        <?php echo csrf_field(); ?>
        <label>Username:</label>
        <input class="input-field" type="text" name="username" required>

        <label>Password:</label>
        <input class="input-field" type="password" name="password" required>

        <div style="text-align:center; margin-top:6px;">
            <button type="submit" class="btn">Login</button>
        </div>
    </form>

    <p>Belum punya akun? <a href="/register" class="btn-secondary">Register</a></p>
    <hr class="ghost-40">

    <footer>
        <p>&copy; GreenLife 2025</p>
    </footer>
</main>
</body>
</html>
<?php /**PATH C:\laragon\www\laravel-greenlife\resources\views/login.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Pengguna - GreenLife</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body class="dashboard-page">

  <!-- HEADER -->
  <header>
    <div class="header-inner">
      <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="GreenLife Logo" class="logo">

      <nav>
        <a href="#" class="active">Dashboard</a>
        <a href="/">Home</a>
        <a href="/admin">Admin</a>
      </nav>

      <!-- Dark Mode -->
      <button id="darkModeToggle" title="Ganti Mode" aria-label="Dark Mode">🌙</button>
    </div>
  </header>

  <!-- MAIN -->
  <main class="main-container">

    <section class="welcome-box">
      <h2>🌿 Selamat Datang, <?php echo e($user->username); ?> 🌿</h2>
      <p>Terima kasih sudah bergabung bersama kami. Yuk, mulai belajar menjaga bumi lebih hijau!</p>
    </section>

    <div class="cards-container">

      <!-- Card Tips -->
      <div class="card">
        <h3>💡 Tips Ramah Lingkungan</h3>
        <p>Pelajari cara menggunakan energi terbarukan dan hidup ramah lingkungan setiap hari.</p>
        <a href="#tipsModal" class="btn">Lihat Tips Lainnya</a>
      </div>

      <!-- Card Edukasi -->
      <div class="card">
        <h3>⚡ Edukasi Energi</h3>
        <p>Matikan lampu dan perangkat elektronik saat tidak digunakan untuk menghemat energi.</p>
        <a href="#edukasiModal" class="btn">Pelajari Sekarang</a>
      </div>

    </div>

    <a href="/logout" class="btn-logout">Logout</a>

  </main>

  <!-- FOOTER -->
  <footer>
    <p>©️ 2025 <i>GreenLife</i> - Bersama Menjaga Lingkungan 🌱</p>
  </footer>

  <!-- MODAL TIPS -->
  <div id="tipsModal" class="modal">
    <div class="modal-content">
      <a href="#" class="close">&times;</a>
      <h2>💡 Tips Ramah Lingkungan</h2>
      <p>Langkah kecil kita bisa berdampak besar bagi bumi! Berikut beberapa tips sederhana:</p>
      <ul>
        <li><b>Kurangi Plastik Sekali Pakai:</b> Gunakan tas kain & botol isi ulang.</li>
        <li><b>Gunakan Transportasi Umum:</b> Kurangi polusi dan hemat energi.</li>
        <li><b>Tanam Pohon di Rumah:</b> Membantu serap karbon.</li>
        <li><b>Daur Ulang Barang Bekas:</b> Ubah barang lama jadi bermanfaat.</li>
        <li><b>Hemat Energi:</b> Gunakan lampu LED & matikan elektronik.</li>
      </ul>
    </div>
  </div>

  <!-- MODAL EDUKASI -->
  <div id="edukasiModal" class="modal">
    <div class="modal-content">
      <a href="#" class="close">&times;</a>
      <h2>⚡ Edukasi Energi</h2>
      <p>Energi adalah bagian penting kehidupan. Gunakan dengan bijak:</p>
      <ul>
        <li><b>Energi Terbarukan:</b> Matahari, air, dan angin.</li>
        <li><b>Hemat Listrik:</b> Matikan perangkat saat tidak dipakai.</li>
        <li><b>Panel Surya:</b> Hemat energi jangka panjang.</li>
        <li><b>Efisiensi Air:</b> Gunakan air sesuai kebutuhan.</li>
        <li><b>Edukasi Dini:</b> Ajak anak peduli lingkungan.</li>
      </ul>
    </div>
  </div>

  <script src="<?php echo e(asset('js/script.js')); ?>"></script>

</body>
</html><?php /**PATH C:\laragon\www\laravel-greenlife\resources\views/user/dashboard.blade.php ENDPATH**/ ?>
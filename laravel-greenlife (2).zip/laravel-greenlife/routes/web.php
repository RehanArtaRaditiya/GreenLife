<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\TipsAdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminAuthController;

// LOGIN ADMIN
Route::get('/login-admin', [AdminAuthController::class, 'login']);
Route::post('/login-admin', [AdminAuthController::class, 'doLogin']);
Route::get('/logout-admin', [AdminAuthController::class, 'logout']);
// DASHBOARD ADMIN
Route::get('/admin', [AdminController::class, 'index']);
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/login', [AuthController::class, 'login']);
Route::post('/login', [AuthController::class, 'doLogin']);
Route::get('/register', [AuthController::class, 'register']);
Route::post('/register', [AuthController::class, 'doRegister']);
Route::get('/logout', [AuthController::class, 'logout']);
// TIPS ADMIN
Route::get('/admin/tips', [TipsAdminController::class, 'index']);
Route::post('/admin/tips/store', [TipsAdminController::class, 'store']);
Route::post('/admin/tips/update', [TipsAdminController::class, 'update']);
Route::get('/admin/tips/hapus/{id}', [TipsAdminController::class, 'destroy']);
Route::get('/', [HomeController::class, 'index']);
Route::get('/admin/tips/cetak', [TipsAdminController::class, 'cetak']);
// EDUKASI ADMIN
Route::get('/admin/edukasi', [App\Http\Controllers\EdukasiAdminController::class, 'index']);
Route::post('/admin/edukasi/store', [App\Http\Controllers\EdukasiAdminController::class, 'store']);
Route::post('/admin/edukasi/update', [App\Http\Controllers\EdukasiAdminController::class, 'update']);
Route::get('/admin/edukasi/hapus/{id}', [App\Http\Controllers\EdukasiAdminController::class, 'destroy']);
Route::get('/admin/edukasi/cetak', [App\Http\Controllers\EdukasiAdminController::class, 'cetak']);

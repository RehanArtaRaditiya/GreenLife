<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{

public function up(): void
{
    if (Schema::hasTable('tb_tips')) {
        return;
    }

    Schema::create('tb_tips', function (Blueprint $table) {
        $table->id('id_tips');
        $table->unsignedBigInteger('id_admin');
        $table->string('judul');
        $table->text('deskripsi');
        $table->timestamps();
    });
}

    public function down(): void
    {
        Schema::dropIfExists('tb_tips');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tb_edukasi', function (Blueprint $table) {
            $table->id('id_edukasi'); 
            $table->unsignedBigInteger('id_admin');
            $table->string('judul');
            $table->text('deskripsi');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tb_edukasi');
    }
};
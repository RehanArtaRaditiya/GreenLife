<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laporan Tips - GreenLife</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }

        h2 {
            text-align: center;
            margin-bottom: 10px;
        }

        .info {
            text-align: center;
            margin-bottom: 20px;
            font-size: 11px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000;
            padding: 6px;
        }

        th {
            background: #f0f0f0;
        }
    </style>
</head>
<body>

<h2>LAPORAN DATA TIPS LINGKUNGAN</h2>
<div class="info">Website GreenLife - Edukasi Lingkungan & Energi</div>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Deskripsi</th>
            <th>Nama Admin</th>
        </tr>
    </thead>
    <tbody>
        @php $no = 1; @endphp
        @foreach($tips as $item)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $item->judul }}</td>
            <td>{{ $item->deskripsi }}</td>
            <td>{{ $item->nama_admin }}</td>
        </tr>
        @endforeach
    </tbody>
</table>

</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Tips Lingkungan</title>

  {{-- CSS --}}
  <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="admin-page">
  <div class="sidebar">
    <img src="{{ asset('assets/logo.png') }}" alt="GreenLife Logo" class="logo-admin">

    <div class="menu">
      <a href="/admin"><i class="fa-solid fa-house"></i> Dashboard</a>

      <a href="/admin/tips" class="active">
        <i class="fa-solid fa-leaf"></i> Tips Lingkungan
      </a>

      <a href="/admin/edukasi">
        <i class="fa-solid fa-bolt"></i> Edukasi Energi
      </a>
    </div>

    <div class="logout">
      <a href="/logout-admin" class="btn-logout">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </a>
    </div>
  </div>

  <div class="main-content">

    <div class="header">
      <h1>💡 Data Tips Lingkungan</h1>
      <div class="admin-name">Admin: {{ session('nama_admin') }}</div>
    </div>

    <div class="content">

      <form method="post" action="{{ isset($editData) ? '/admin/tips/update' : '/admin/tips/store' }}">
        @csrf

        @if ($editData)
          <input type="hidden" name="id_tips" value="{{ $editData->id_tips }}">
          <input type="text" name="judul" value="{{ $editData->judul }}" required>
          <input type="text" name="deskripsi" value="{{ $editData->deskripsi }}" required>

          <button type="submit" class="btn-add">Simpan Perubahan</button>
          <a href="/admin/tips" class="btn-cancel">Batal</a>

        @else
          <input type="text" name="judul" placeholder="Judul Tips" required>
          <input type="text" name="deskripsi" placeholder="Deskripsi Tips" required>

          <button type="submit" class="btn-add">+ Tambah Tips</button>
        @endif
      </form>

      <div style="margin: 15px 0;">
        <a href="/admin/tips/cetak" class="btn-print-modern">
          <i class="fa-solid fa-print"></i> Cetak PDF
        </a>
      </div>

      <table class="table">
        <thead>
          <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Deskripsi</th>
            <th>Admin</th>
            <th>Aksi</th>
          </tr>
        </thead>

        <tbody>
          @php $no = 1; @endphp
          @foreach ($tipsData as $item)
          <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $item->judul }}</td>
            <td>{{ $item->deskripsi }}</td>
            <td>{{ $item->nama_admin }}</td>
            <td>
              <a href="/admin/tips?edit={{ $item->id_tips }}" class="btn-edit">Edit</a>

              <a href="/admin/tips/hapus/{{ $item->id_tips }}"
                 onclick="return confirm('Yakin hapus data ini?')"
                 class="btn-delete">
                 Hapus
              </a>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>

    </div>
  </div>

</div>

</body>
</html>
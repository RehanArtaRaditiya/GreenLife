<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>GreenLife - Login Admin</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <main class="main-container center">
        <img src="{{ asset('assets/logo.png') }}" class="logo">
        <h2>Login Admin</h2>
        <p class="tagline">Akses khusus administrator.</p>
        <hr class="ghost-60">

        @if (session('error'))
            <p style="color:red;font-weight:bold">{{ session('error') }}</p>
        @endif

        <form method="POST" action="/login-admin" class="form">
            @csrf

            <label>Username:</label>
            <input class="input-field" type="text" name="username" required>

            <label>Password:</label>
            <input class="input-field" type="password" name="password" required>

            <div style="text-align:center;margin-top:6px;">
                <button type="submit" class="btn">Login</button>
            </div>
        </form>

        <hr class="ghost-40">
        <footer>
            <p>&copy; GreenLife 2025</p>
        </footer>
    </main>
</body>
</html>

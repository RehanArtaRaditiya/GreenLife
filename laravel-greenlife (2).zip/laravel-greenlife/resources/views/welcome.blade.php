<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GreenLife - Home</title>
  <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>

<body>
  <!-- ===== HEADER ===== -->
  <header>
    <div class="header-inner">
      <div>
        <img src="{{ asset('assets/logo.png') }}" alt="Logo GreenLife" class="logo">
      </div>
      <nav>
        <a href="/" class="active">Home</a>
        <a href="/login">Login</a>
        <a href="/register">Register</a>
      </nav>
      <button id="darkModeToggle" title="Ganti Mode" aria-label="Dark Mode">🌙</button>
    </div>
  </header>

  <!-- ===== MAIN CONTENT ===== -->
  <main class="main-container center">
    <h1>{{ $greeting }}</h1>
    <p class="tagline">Bersama GreenLife kita belajar menjaga bumi lebih hijau</p>
    <hr class="ghost-60">

    <img src="{{ asset('assets/banner.png') }}" alt="Banner GreenLife" class="banner">

    <section class="about">
      <h2>Tentang GreenLife</h2>
      <p>
        GreenLife adalah portal edukasi yang membahas tentang pentingnya hemat energi dan menjaga lingkungan.
        Melalui web ini, pengguna bisa mendapatkan informasi tentang energi terbarukan, tips gaya hidup ramah lingkungan,
        serta ajakan untuk berpartisipasi dalam menjaga bumi agar tetap hijau dan berkelanjutan.
      </p>
    </section>

    <!-- ===== BOX JUMLAH PENGUNJUNG ===== -->
    <div style="
      background: #dcfce7; 
      padding: 12px; 
      border-radius: 8px; 
      margin-top: 20px; 
      box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
      color: #166534;
    ">
      🌿 Sudah {{ $currentVisitors }} orang bergabung menjaga lingkungan hari ini!
    </div>

    <!-- ===== TOMBOL INTERAKTIF ===== -->
    <button class="btn" style="margin-top: 20px;">
      Saya Siap Menjaga Lingkungan!
    </button>

    <hr class="ghost-40">
  </main>

  <!-- ===== FOOTER ===== -->
  <footer>
    <p><strong>Selamat datang di GreenLife!</strong></p>
    <p>&copy; 2025 GreenLife — Bersama Menjaga Lingkungan</p>
  </footer>

  <!-- ===== SNACKBAR (Toast Message) ===== -->
  <div id="snackbar">Terima kasih telah peduli lingkungan 🌱</div>

  <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>

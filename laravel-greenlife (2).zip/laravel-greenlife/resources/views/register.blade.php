<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>GreenLife - Register</title>
  <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
<main class="main-container center">
  <img src="{{ asset('assets/logo.png') }}" alt="GreenLife Logo" class="logo">
  <h2>Daftar ke GreenLife</h2>
  <p class="tagline">Bergabunglah bersama kami untuk menjaga bumi lebih hijau!</p>
  <hr class="ghost-60">

  @if (session('error'))
    <p style="color:red;">{{ session('error') }}</p>
  @endif

  @if (session('success'))
    <p style="color:green;">{{ session('success') }}</p>
  @endif

  <form action="/register" method="post" class="form">
    @csrf

    <label>Nama Lengkap:</label>
    <input class="input-field" type="text" name="nama" required>

    <label>Username:</label>
    <input class="input-field" type="text" name="username" required>

    <label>Email:</label>
    <input class="input-field" type="email" name="email" required>

    <label>Password:</label>
    <input class="input-field" type="password" name="password" required>

    <label>Konfirmasi Password:</label>
    <input class="input-field" type="password" name="confirm_password" required>

    <div style="text-align:center; margin-top:6px;">
      <button type="submit" class="btn">Register</button>
    </div>
  </form>

  <p>Sudah punya akun? <a href="/login" class="btn-secondary">Login</a></p>
  <hr class="ghost-40">
  <footer>
    <p>&copy; GreenLife 2025</p>
  </footer>
</main>

<script src="{{ asset('js/script.js') }}"></script>
</body>
</html>

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Edukasi extends Model
{
    protected $table = 'tb_edukasi';
    protected $primaryKey = 'id_edukasi';

    public $timestamps = false; // ← MATIKAN TIMESTAMPS

    protected $fillable = [
        'id_admin',
        'judul',
        'deskripsi'
    ];
}
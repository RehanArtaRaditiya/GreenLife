<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoginLog extends Model
{
    protected $table = 'tb_login';
    protected $primaryKey = 'id_login';

    protected $fillable = [
        'id_user',
        'id_admin',
        'waktu_login',
        'waktu_logout',
        'status'
    ];
}

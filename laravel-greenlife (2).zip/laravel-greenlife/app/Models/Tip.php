<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tip extends Model
{
    use HasFactory;

    protected $table = 'tb_tips';
    protected $primaryKey = 'id_tips';
    public $timestamps = false;

    protected $fillable = [
        'id_admin',
        'judul',
        'deskripsi'
    ];
}

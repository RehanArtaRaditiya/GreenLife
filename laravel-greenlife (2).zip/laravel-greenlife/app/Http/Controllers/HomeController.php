<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        // Greeting berdasarkan waktu
        $hour = date('H');

        if ($hour < 12) {
            $greeting = "Selamat Pagi! 🌞 Hemat Energi, Selamatkan Lingkungan";
        } elseif ($hour < 18) {
            $greeting = "Selamat Siang! ☀️ Hemat Energi, Selamatkan Lingkungan";
        } else {
            $greeting = "Selamat Malam! 🌙 Hemat Energi, Selamatkan Lingkungan";
        }

        // Simulasi jumlah pengunjung
        $visitorFile = public_path('visitors.txt');

        $currentVisitors = file_exists($visitorFile)
            ? (int) file_get_contents($visitorFile)
            : 100;

        $currentVisitors += rand(1, 10);

        file_put_contents($visitorFile, $currentVisitors);

        return view('welcome', compact('greeting', 'currentVisitors'));
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tip;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Barryvdh\DomPDF\Facade\Pdf; 

class TipsAdminController extends Controller
{
    public function index()
    {
        // Cek login admin
        if (!session()->has('id_admin')) {
            return redirect('/login');
        }

        // Ambil data tips + admin
        $tipsData = DB::table('tb_tips')
            ->leftJoin('tb_admin', 'tb_tips.id_admin', '=', 'tb_admin.id_admin')
            ->select('tb_tips.*', 'tb_admin.nama_admin')
            ->orderBy('id_tips', 'asc')
            ->get();

        $editData = null;

        if (request('edit')) {
            $editData = Tip::find(request('edit'));
        }

        return view('admin.tips-admin', compact('tipsData', 'editData'));
    }

    public function store(Request $request)
    {
        $id_admin = session('id_admin');

        Tip::create([
            'id_admin' => $id_admin,
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi
        ]);

        return redirect('/admin/tips');
    }

    public function update(Request $request)
    {
        $tip = Tip::find($request->id_tips);

        $tip->update([
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi
        ]);

        return redirect('/admin/tips');
    }

    public function destroy($id)
    {
        Tip::destroy($id);

        return redirect('/admin/tips');
    }

    public function cetak()
    {
    // Ambil data tips + admin
    $tips = \DB::table('tb_tips')
        ->leftJoin('tb_admin', 'tb_tips.id_admin', '=', 'tb_admin.id_admin')
        ->select('tb_tips.*', 'tb_admin.nama_admin')
        ->orderBy('id_tips', 'asc')
        ->get();

    $pdf = Pdf::loadView('admin.tips-pdf', compact('tips'));
    return $pdf->download('laporan_tips_greenlife.pdf');
    }
}

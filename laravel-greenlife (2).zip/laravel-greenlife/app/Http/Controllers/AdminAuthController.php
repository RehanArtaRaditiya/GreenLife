<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\LoginLog;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class AdminAuthController extends Controller
{
    // TAMPILKAN FORM LOGIN ADMIN
    public function login()
    {
        return view('admin.login');
    }

    // PROSES LOGIN ADMIN
    public function doLogin(Request $request)
    {
        $admin = Admin::where('username', $request->username)->first();

        if ($admin && Hash::check($request->password, $admin->password)) {

            // SET SESSION
            session([
                'id_admin'   => $admin->id_admin,
                'username'   => $admin->username,
                'nama_admin' => $admin->nama_admin,
                'role'        => 'admin'
            ]);

            // CATAT LOGIN KE tb_login
            LoginLog::create([
                'id_admin'     => $admin->id_admin,
                'waktu_login'  => Carbon::now(),
                'status'       => 'online'
            ]);

            return redirect('/admin');

        } 
        else {
            return back()->with('error', 'Username atau Password salah!');
        }
    }


    // LOGOUT ADMIN
    public function logout()
    {
        if (session()->has('id_admin')) {

            LoginLog::where('id_admin', session('id_admin'))
                ->latest()
                ->update([
                    'waktu_logout' => Carbon::now(),
                    'status' => 'offline'
                ]);

        }

        session()->flush();
        return redirect('/');
    }
}

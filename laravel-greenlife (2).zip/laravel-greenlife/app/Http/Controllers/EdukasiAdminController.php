<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Edukasi;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;


class EdukasiAdminController extends Controller
{
    public function index()
    {
        if (!session()->has('id_admin')) {
            return redirect('/login-admin');
        }

        // Ambil data edukasi + admin
        $edukasiData = DB::table('tb_edukasi')
            ->leftJoin('tb_admin', 'tb_edukasi.id_admin', '=', 'tb_admin.id_admin')
            ->select('tb_edukasi.*', 'tb_admin.nama_admin')
            ->orderBy('id_edukasi', 'asc')
            ->get();

        $editData = null;

        if (request('edit')) {
            $editData = Edukasi::find(request('edit'));
        }

        return view('admin.edukasi-admin', compact('edukasiData', 'editData'));
    }

    public function store(Request $request)
    {
        $id_admin = session('id_admin');

        Edukasi::create([
            'id_admin'   => $id_admin,
            'judul'      => $request->judul,
            'deskripsi'  => $request->deskripsi
        ]);

        return redirect('/admin/edukasi');
    }

    public function update(Request $request)
    {
        $edukasi = Edukasi::find($request->id_edukasi);

        $edukasi->update([
            'judul'     => $request->judul,
            'deskripsi' => $request->deskripsi
        ]);

        return redirect('/admin/edukasi');
    }

    public function destroy($id)
    {
        Edukasi::destroy($id);

        return redirect('/admin/edukasi');
    }

    public function cetak()
    {
    // Ambil data edukasi + admin
    $edukasi = \DB::table('tb_edukasi')
        ->leftJoin('tb_admin', 'tb_edukasi.id_admin', '=', 'tb_admin.id_admin')
        ->select('tb_edukasi.*', 'tb_admin.nama_admin')
        ->orderBy('id_edukasi', 'asc')
        ->get();

    $pdf = Pdf::loadView('admin.edukasi-pdf', compact('edukasi'));
    return $pdf->download('laporan_edukasi_greenlife.pdf');
    }
}
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        // Cek pakai SESSION (sesuai loginmu)
        if (!session()->has('id_user')) {
            return redirect('/login');
        }

        $user = (object) [
            'id_user'   => session('id_user'),
            'username'  => session('username'),
            'nama_user' => session('nama_user'),
            'role'      => session('role'),
        ];

        return view('user.dashboard', compact('user'));
    }
}

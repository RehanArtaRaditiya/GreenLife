<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\LoginLog;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;

class AuthController extends Controller
{
    public function login()
    {
        return view('login');
    }

    public function register()
    {
        return view('register');
    }

    // LOGIN USER
    public function doLogin(Request $request)
    {
        $user = User::where('username', $request->username)->first();

        if ($user && Hash::check($request->password, $user->password)) {

            session([
                'id_user'   => $user->id_user,
                'username'  => $user->username,
                'nama_user' => $user->nama_user,
                'role'       => 'user'
            ]);

            // simpan ke tb_login
            LoginLog::create([
                'id_user'      => $user->id_user,
                'waktu_login'  => Carbon::now(),
                'status'       => 'online'
            ]);

            return redirect('/dashboard');
        } else {
            return back()->with('error', 'Username atau password salah!');
        }
    }

    // REGISTER USER
    public function doRegister(Request $request)
    {
        if ($request->password !== $request->confirm_password) {
            return back()->with('error', 'Password tidak cocok!');
        }

        if (User::where('username', $request->username)->exists()) {
            return back()->with('error', 'Username sudah digunakan!');
        }

        User::create([
            'nama_user' => $request->nama,
            'username'  => $request->username,
            'email'     => $request->email,
            'password'  => Hash::make($request->password)
        ]);

        return redirect('/login')->with('success', 'Registrasi berhasil! Silakan login.');
    }

    // LOGOUT
    public function logout()
    {
        if (session()->has('id_user')) {
            LoginLog::where('id_user', session('id_user'))
                ->latest()
                ->update([
                    'waktu_logout' => Carbon::now(),
                    'status' => 'offline'
                ]);
        }

        session()->flush();
        return redirect('/');
    }
}

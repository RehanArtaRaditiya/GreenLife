<?php

namespace App\Http\Controllers;

use App\Models\Tip;
use App\Models\Admin;
use App\Models\Edukasi;

class AdminController extends Controller
{
    public function index()
    {
        // ✅ CEK LOGIN ADMIN (SESSION MANUAL, BUKAN Auth::guard)
        if (!session()->has('id_admin') || session('role') !== 'admin') {
            return redirect('/login-admin');
        }

        // ✅ HITUNG DATA
        $jmlTips    = Tip::count();
        $jmlEdukasi = Edukasi::count();
        $jmlAdmin   = Admin::count();

        return view('admin.dashboard', compact('jmlTips', 'jmlEdukasi', 'jmlAdmin'));
    }
}
